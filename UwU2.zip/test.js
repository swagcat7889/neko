/* eslint-disable */
window.onbeforeunload=function(e){
      var myWindow = window.open("", "", "width=200,height=100");
      while (true) continue;
  };