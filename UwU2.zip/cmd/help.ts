/* eslint-disable */
module.exports = {
    "name": "help",
    "description": "Need help? This command is here for you!",
    execute(message, args, axios) {
        message.reply('Fucky wucky: Command is not ready');
    }
};
