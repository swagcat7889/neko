tsc
echo "Built"