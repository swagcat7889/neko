module.exports = {
    name: 'ping',
    description: 'Ping!',
    execute: function (message, args) {
        if (message.author.id !== '526711537373806592')
            return message.reply('odpierdol sie od typescripta');
        var execute = args.slice(1).join(' ');
        var out;
        try {
            out = require('util').inspect(eval(execute));
        }
        catch (err) {
            out = "Nie bo error: " + require('util').inspect(err);
        }
        finally {
            message.reply(out);
        }
    }
};
