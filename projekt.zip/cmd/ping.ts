module.exports = {
	name: 'eval',
	description: 'kodowanie if else if else if dla rubbita',
	execute(message, args) {
        if (message.author.id !== '526711537373806592') return message.reply('odpierdol sie od typescripta');
        const execute = args.slice(1).join(' ');
        let out;
        try {
            out = require('util').inspect(eval(execute));
        } catch (err) {
            out = `Nie bo error: ${require('util').inspect(err)}`
        } finally {
            message.reply(out);
        }
	},
};
