const { Client, Intents, Collection } = require('discord.js');
const { token, prefix } = require('./package.json');
const fs = require('fs');
const cat = new Intents();
cat.add(32767);
const client = new Client({ intents: [cat] });
client.commands = new Collection();
const catlol = 'cat';
client.on('ready', async () => {
  console.log('Bot is ready!');
});
const commandFiles = fs.readdirSync('./cmd').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
	const command = require(`./cmd/${file}`);
	// set a new item in the Collection
	// with the key as the command name and the value as the exported module
	client.commands.set(command.name, command);
}
client.on('messageCreate', async (message) => {
    if (!message.content.startsWith(prefix) || message.author.bot) return;

	const args = message.content.slice(prefix.length).trim().split(/ +/);
	const command = args.shift().toLowerCase();

	if (!client.commands.has(command)) return;

	try {
		client.commands.get(command).execute(message, args);
	} catch (error) {
		console.error(error);
		message.reply('err');
	}
})
client.on('messageCreate', async (message) => {
  return;
  console.log(`messedż krijejt! kontend: ${message.author.tag}: ${message.content}`);
  if (message.author.bot) return;
  if (!message.content.startsWith(prefix)) return;
  const command = message.content.slice(prefix.length);
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  if (command === 'status') {
      message.reply(`TypeScript: true\nGateway Ping: ${message.client.ws.ping}ms\n${Date.now()} ${message.createdTimestamp}\n${require('discord.js').version}`);
  } else if (command === 'cat') {
      message.reply('not found');  
  } else if (command.startsWith('eval')) {
  } else {
      return;
  }
});
client.on('messageCreate', async (message) => {
    if (message.content.toLowerCase() === `<@!${message.client.user.id}> ile masz iq?` || message.content.toLowerCase() === `<@${message.client.user.id}> ile masz iq?`) {
        return message.reply('4 litry');
    }
})
client.on('messageUpdate', async (message) => {
  console.log(`Edit! ${message.author.tag}: ${message.content}`);
});
client.login(token);
process.on('unhandledRejection', async (rejection) => {
    if (rejection == undefined) return;
    console.log('SwagCat TS unhandledRejection:');
    console.log(rejection);
    process.exit();
});