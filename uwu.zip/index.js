/* eslint-disable */
// require('heapdump');
// process.kill(process.pid, 'SIGUSR1');
const { Client, Intents, Collection } = require("discord.js");
const discord = require('discord.js');
const { token, prefix } = require("./package.json");
const fs = require("fs");
const axios = require('axios').default;
const owoify = require('owoify-js').default;
//     cat = new Intents();
// cat.add(32767);
const client = new Client({ "intents": [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
client.commands = new Collection();
const catlol = "cat";
client.on("ready", async () => {
    console.log(`UwU || Logged in as ${client.user.username} waifu`);
    client.user.setActivity(`${prefix} pwefix | ${client.ws.ping}ms`, { type: 'LISTENING' });
    client.emit('dbg', '[UwU] Stats posted!');
});
client.on('dbg', async (dbg) => {
    console.log(dbg);
});
setInterval(function () {
    client.user.setActivity(`${prefix} pwefix | ${client.ws.ping}ms`, { type: 'LISTENING' });
    client.emit('dbg', '[UwU] Stats posted!');
}, 15000);
const commandFiles = fs.readdirSync("./cmd").filter((file) => file.endsWith(".js"));
for (const file of commandFiles) {
    const command = require(`./cmd/${file}`);
    /*
     * Set a new item in the Collection
     * With the key as the command name and the value as the exported module
     */
    client.commands.set(command.name, command);
}
client.on("messageCreate", async (message) => {
    if (!message.content.startsWith(prefix) || message.author.bot) {
        return;
    }
    const args = message.content.slice(prefix.length).trim().split(/ +/), command = args.shift().toLowerCase();
    if (!client.commands.has(command)) {
        return;
    }
    try {
        client.commands.get(command).execute(message, args, axios, discord);
    }
    catch (error) {
        console.error(error);
        message.reply(`Fucky wucky an ewwow occuwwed: ${owoify(error.toString(), 'ovo')}`);
    }
});
client.login(token);
process.on("unhandledRejection", async (rejection) => {
    if (rejection === undefined) {
        return;
    }
    console.log("SwagCat TS unhandledRejection:");
    console.log(rejection);
    process.kill(process.pid, 'SIGUSR2');
    console.log('dumped memory');
});
