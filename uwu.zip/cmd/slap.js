/* eslint-disable sort-keys */
/* eslint-disable no-eval */
/* eslint-disable */
module.exports = {
    "name": "slap",
    "description": "Hey, that hurts!",
    execute(message, args, axios) {
        axios.get('https://nekos.life/api/v2/img/slap')
            .then(function (response) {
            // handle success
            message.reply(`${response.data.url}`);
        })
            .catch(function (error) {
            // handle error
            message.reply(`fucky wucky: ${error}`);
        });
    }
};
